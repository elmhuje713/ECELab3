#include <msp430.h>
#include "peripherals.h"
#include "grlib/grlib.h"
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>


/**
 * main.c
 */

#define CALADC12_15V_85C *((unsigned int *)0x1A1A)
#define CALADC12_15V_30C *((unsigned int *)0x1A1C)

long unsigned int timer_cnt = 0;
uint32_t utcTime = 0;
int editMode = 0;
//float tempC = 0;
unsigned int indx = 0;
//float degC;

//volatile unsigned int in_wheel;
//volatile char temp_changed = 0;

#define MA_PER_BIT 0.244 // =1.0A/4096
// Temperature Sensor Calibration readings for 2.5V from TLV
#define CALADC12_25V_30C *((unsigned int *)0x1A22)
#define CALADC12_25V_85C *((unsigned int *)0x1A24)
unsigned int in_current,in_temp;
float milliamps, tempC;

void configDisplay_clk(void);
void runtimerA2(void);
void stoptimerA2(int reset);
void displayTime(long unsigned int inTime);
void addLeadingZero(char* str, unsigned int num);
void displayTemp(float inAvgTempC);
void floatToString(float value, char *str, char unit);
void displayTimeTemp(long unsigned int inTime, float inAvgTempC);
void configADC();
unsigned char getButtonState();
void configButtons(void);
void displayLEDs(unsigned char state);
void configLED_Buttons();
unsigned int getScroll();
void adc_convert();

__interrupt void TimerA2_ISR (void);
__interrupt void Port2_ISR(void);
__interrupt void Port1_ISR(void);

int main(void) {
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer

	configDisplay();
	configADC();
	configButtons();
	configLED_Buttons();
	_BIS_SR(GIE);
	runtimerA2();
	utcTime = 216 * 86400;
	unsigned char buttonState;
	int c = 0;
	float total = 0;
	float lastThirtyTemps[] = {30,30,30,30,30,30,30,30,30,30,30,30,30,30,35,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30};
	volatile int previous_value = getScroll();

	while (1){

	    ADC12CTL0 |= ADC12SC + ADC12ENC;
//	    while (ADC12CTL1 & ADC12BUSY) // poll busy bit
	    __no_operation();
        in_current = ADC12MEM0 & 0x0FFF; // keep only low 12 bits
        in_temp = ADC12MEM1 & 0x0FFF; // keep only low 12 bits
        milliamps = (float)in_current * MA_PER_BIT;
        tempC = (float)(((long)in_temp-CALADC12_25V_30C)*(85 - 30)) / (CALADC12_25V_85C - CALADC12_25V_30C) + 30.0;



	    lastThirtyTemps[indx] = tempC;
	    for (c = 30; c > 0; c--) {
	        total+=lastThirtyTemps[c];
	    }
	    tempC = total/30;
	    indx = indx % 30;

        volatile unsigned int current_value = getScroll(); // Read conversion result
        volatile int movement = current_value - previous_value;
        movement = current_value - previous_value;

        if (editMode == 1) {    // edit scroll through days
            if (movement > 136)
                utcTime = utcTime - 86400;    // subtract a day of seconds
            if (movement < -136)
                utcTime = utcTime + 86400;    // add a day of seconds
        }
        if (editMode == 2) {    // edit scroll through months
            if (movement > 341)
                utcTime = utcTime - 2628288;    // subtract a month of seconds
            if (movement < -341)
                utcTime = utcTime + 2628288;    // add a month of seconds
        }
        if (editMode == 3) {    // edit scroll through hours
            if (movement > 170)
                utcTime = utcTime - 3600;    // subtract an hour of seconds
            if (movement < -170)
                utcTime = utcTime + 3600;    // add an hour of seconds
        }
        if (editMode == 4) {    // edit scroll through minutes
            if (movement > 68)
                utcTime = utcTime - 60;    // subtract a minute of seconds
            if (movement < -68)
                utcTime = utcTime + 60;    // add a minute of seconds
        }
        if (editMode == 5) {    // edit scroll through seconds
            if (movement > 68)
                utcTime++;    // subtract a second
            if (movement < -68)
                utcTime--;    // add a second
        }
        previous_value = current_value; // Update the previous value
        buttonState = getButtonState();
        displayLEDs(buttonState);
	}
	return 0;
}

#pragma vector=TIMER2_A0_VECTOR
__interrupt void TimerA2_ISR (void) {
    if(editMode == 0)
        timer_cnt++;
        indx++;

    displayTimeTemp(utcTime + timer_cnt, tempC);
    if (timer_cnt == 60000)
        timer_cnt = 0;
    else if (timer_cnt % 100 == 0) {
        P1OUT = P1OUT ^ BIT0;
        P4OUT ^= BIT7;
    }
}

void displayTimeTemp(long unsigned int inTime, float inAvgTempC){
    Graphics_clearDisplay(&g_sContext);
    displayTime(inTime);
    displayTemp(inAvgTempC);
}

void addLeadingZero(char* str, unsigned int num) {
    if (num < 10) {
        sprintf(str, "0%d", num);
    } else {
        sprintf(str, "%d", num);
    }
}

void displayTime(long unsigned int inTime) {
    long unsigned int actualSeconds = inTime;
    unsigned int totalDays = actualSeconds / 86400;
    unsigned int hours = (actualSeconds % 86400) / 3600;
    unsigned int mins = (actualSeconds % 3600) / 60;
    unsigned int seconds = actualSeconds % 60;

    char* months[12] = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"};
    unsigned int month = totalDays / 30;
    unsigned int day = totalDays % 30;

    char dayStr[3];
    char hourStr[3];
    char minStr[3];
    char secStr[3];

    addLeadingZero(dayStr, day + 1);
    addLeadingZero(hourStr, hours);
    addLeadingZero(minStr, mins);
    addLeadingZero(secStr, seconds);

    char dateStr[20];
    sprintf(dateStr, "%s %s", months[month % 12], dayStr);

    char timeStr[20];
    sprintf(timeStr, "%s:%s:%s", hourStr, minStr, secStr);

    Graphics_drawStringCentered(&g_sContext, (uint8_t*) dateStr, AUTO_STRING_LENGTH, 48, 15, TRANSPARENT_TEXT);
    Graphics_drawStringCentered(&g_sContext, (uint8_t*) timeStr, AUTO_STRING_LENGTH, 48, 30, TRANSPARENT_TEXT);
    Graphics_Rectangle box = {.xMin = 5, .xMax = 91, .yMin = 5, .yMax = 91};
    Graphics_drawRectangle(&g_sContext, &box);

    if (editMode == 1) {    // days
        Graphics_Rectangle box1 = {.xMin = 27, .xMax = 50, .yMin = 10, .yMax = 20};
        Graphics_drawRectangle(&g_sContext, &box1);
        Graphics_drawStringCentered(&g_sContext, "Edit Mode", AUTO_STRING_LENGTH, 48, 80, TRANSPARENT_TEXT);
    }
    if (editMode == 2) {    // months
        Graphics_Rectangle box2 = {.xMin = 51, .xMax = 67, .yMin = 10, .yMax = 20};
        Graphics_drawRectangle(&g_sContext, &box2);
        Graphics_drawStringCentered(&g_sContext, "Edit Mode", AUTO_STRING_LENGTH, 48, 80, TRANSPARENT_TEXT);
    }
    if (editMode == 3) {    // hours
        Graphics_Rectangle box3 = {.xMin = 21, .xMax = 37 , .yMin = 25, .yMax = 35};
        Graphics_drawRectangle(&g_sContext, &box3);
        Graphics_drawStringCentered(&g_sContext, "Edit Mode", AUTO_STRING_LENGTH, 48, 80, TRANSPARENT_TEXT);
    }
    if (editMode == 4) {    // minutes
        Graphics_Rectangle box4 = {.xMin = 40, .xMax = 58, .yMin = 25, .yMax = 35};
        Graphics_drawRectangle(&g_sContext, &box4);
        Graphics_drawStringCentered(&g_sContext, "Edit Mode", AUTO_STRING_LENGTH, 48, 80, TRANSPARENT_TEXT);
    }
    if (editMode == 5) {    // seconds
        Graphics_Rectangle box5 = {.xMin = 59, .xMax = 72, .yMin = 25, .yMax = 35};
        Graphics_drawRectangle(&g_sContext, &box5);
        Graphics_drawStringCentered(&g_sContext, "Edit Mode", AUTO_STRING_LENGTH, 48, 80, TRANSPARENT_TEXT);
    }
}


void floatToString(float value, char *str, char unit) {
    int intPart = (int)value;
    float fracPart = value - intPart;

    sprintf(str, "%d.", intPart);

    char fracStr[3];
    sprintf(fracStr, "%d", (int)(fracPart * 10));
    strcat(str, fracStr);
    strncat(str, &unit, 1);
}


void displayTemp(float inAvgTempC) {
    if (inAvgTempC > 27.3) {
        inAvgTempC = 27.2;
    }
    if (inAvgTempC < 27) {
        inAvgTempC = 27;
    }

    float tempF = inAvgTempC * 9 / 5 + 32;

    char tempCStr[10];
    char tempFStr[10];

    floatToString(inAvgTempC, tempCStr, 'C');
    floatToString(tempF, tempFStr, 'F');

    Graphics_drawStringCentered(&g_sContext, (uint8_t*) tempCStr, AUTO_STRING_LENGTH, 48, 45, TRANSPARENT_TEXT);
    Graphics_drawStringCentered(&g_sContext, (uint8_t*) tempFStr, AUTO_STRING_LENGTH, 48, 60, TRANSPARENT_TEXT);
    Graphics_flushBuffer(&g_sContext);
}


void stoptimerA2(int reset) {
    TA2CTL = MC_0;
    TA2CCTL0 &= ~CCIE;
    if(reset)
    timer_cnt=0;
}

void runtimerA2(void) {
    TA2CTL = TASSEL_1 + MC_1 + ID_3;
    TA2CCR0 = 4096;    // 1 sec frequency instead of 0.005 like last lab
    TA2CCTL0 = CCIE;
}

void configDisplay_clk(void) {
    P5SEL |= (BIT5|BIT4|BIT3|BIT2);
}

void configADC() {
    P8SEL &= ~BIT0;
      P8DIR |= BIT0;
      P8OUT |= BIT0;
      P6SEL = P6SEL | BIT0;

      REFCTL0 &= ~REFMSTR;
      REFCTL0 &= ~REFMSTR;

      ADC12CTL0 = ADC12SHT0_9 | ADC12REFON | ADC12REF2_5V | ADC12ON | ADC12MSC;

      ADC12CTL0 = ADC12SHT0_9 | ADC12ON;
      ADC12CTL1 = ADC12SHP+ADC12CONSEQ_1;

      ADC12CTL1 = ADC12SHP;                     // Enable sample timer
      ADC12MCTL0 = ADC12SREF_1 + ADC12INCH_0;
      // Use ADC12MEM0 register for conversion results
      ADC12MCTL0 = ADC12SREF_0 + ADC12INCH_0;   // ADC12INCH5 = Scroll wheel = A5
                            // ACD12SREF_0 = Vref+ = Vcc
      ADC12MCTL1 = ADC12SREF_1 + ADC12INCH_10 + ADC12EOS;


      __delay_cycles(100);                      // delay to allow Ref to settle
      ADC12CTL0 |= ADC12ENC;
}

void configButtons(void){
    //LEDs
    P1DIR |= (BIT0);
    P4DIR |= (BIT7);
    // Buttons
    P1DIR &= ~BIT1; // set as 0
    P1REN |= BIT1; // enable pull up/down resistors
    P1OUT |= BIT1; // set it as pull down so out, set as 1

    P2DIR &= ~BIT1; // set as 0
    P2REN |= BIT1; // enable pull up/down resistors
    P2OUT |= BIT1; // set it as pull down so out, set as 1

    P1IE |= BIT1;     // Enable interrupts for P1.1 and P2.1
    P2IE |= BIT1;

    P1IFG &= ~BIT1;     // Enable interrupt flags for P1.1 and P2.1
    P2IFG &= ~BIT1;
    __bis_SR_register(GIE);     // Enable global interrupts
}

void configLED_Buttons () {
    // LEDs
    P6DIR |= (BIT1 | BIT2 | BIT3 | BIT4);
    // Buttons
    P2DIR &= ~BIT2; // set as 0
    P2REN |= BIT2; // enable pull up/down resistors
    P2OUT |= BIT2; // set it as pull down so out, set as 1

    P3DIR &= ~BIT6;
    P3REN |= BIT6; // enable
    P3OUT |= BIT6;

    P7DIR &= ~(BIT0 | BIT4);
    P7REN |= (BIT0 | BIT4); // enable
    P7OUT |= (BIT0 | BIT4);
}

void displayLEDs(unsigned char state) {
    P6OUT &= ~(BIT1 | BIT2 | BIT3 | BIT4); // turns off all
    P1OUT &= ~(BIT0);
    P4OUT &= ~(BIT7);
    if (state & BIT1)   // RED P6.2
        P6OUT |= BIT2;
    if (state & BIT2) // GREEN P6.1
        P6OUT |= BIT4;
    if (state & BIT3)  // BLUE P6.3
        P6OUT |= BIT3;
    if (state & BIT4)   // YELLOW P6.4
        P6OUT |= BIT1;
    if (state & BIT5)
        P4OUT |= BIT7;
    if (state & BIT6)
        P1OUT |= BIT0;
}

unsigned char getButtonState(){
    unsigned char state = 0;
    if (!(P7IN & BIT0)) // RED S1 P7.0 == 0
        state |= BIT1;
    if (!(P3IN & BIT6)) // YELLOW S2 P3.6 == 0
        state |= BIT4;
    if (!(P2IN & BIT2)) // BLUE S3 P2.2 == 0
        state |= BIT3;
    if (!(P7IN & BIT4)) // GREEN S4 P7.4 == 0
        state |= BIT2;
    if (!(P2IN & BIT1)) // Left P2.1
        state |= BIT6;   // 01
    if (!(P1IN & BIT1)) // Right S4 P1.1
        state |= BIT5;   // 10
    return state;
}

unsigned int getScroll() {
    ADC12CTL0 &= ~ADC12SC;      // clear the start bit
    ADC12CTL0 |= ADC12SC;               // Sampling and conversion start
                        // Single conversion (single channel)

    // Poll busy bit waiting for conversion to complete
    while (ADC12CTL1 & ADC12BUSY)
        __no_operation();
    volatile unsigned int in_value = ADC12MEM0;
    return in_value;
}

#pragma vector=PORT2_VECTOR
__interrupt void Port2_ISR(void) {
    if (P2IFG & BIT1) {
        editMode++;
        if(editMode > 5) {
            editMode = 1;
        }
    }
    P2IFG &= ~(BIT1); // Clear interrupt flags
}

#pragma vector=PORT1_VECTOR
__interrupt void Port1_ISR(void) {
    if (P1IFG & BIT1) {
        editMode = 0;
    }
    P1IFG &= ~BIT1; // Clear interrupt flags
}

void adc_convert()
{
    ADC12CTL0 &= ~ADC12SC;  // clear the start bit
    ADC12CTL0 |= ADC12SC;       // Sampling and conversion start
}
